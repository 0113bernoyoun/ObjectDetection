BBox-Label-Tool
===============

# 1. Dependency
python=2.7 
PIL

# 2. Images
Images/001   *# direcotry containing the images to be labeled*  

|--Labels/   *# direcotry for the labeling results* 

